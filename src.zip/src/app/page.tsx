import React from "react";
import HeroSection from "@/components/home/HeroSection";
import Navbar from "@/components/home/navbar";
import About from "@/components/home/About";
import SkillsSection from "@/components/home/Skill";
import ProjectsSection from "@/components/home/project";
import ContactSection from "@/components/home/Contact";
import Footer from "@/components/home/Footer";
import ExperienceTimeline from "@/components/home/Experience";

const HomePage = () => {
  return (
    <div className="overflow-x-hidden">
      <Navbar />
      <HeroSection />
      <About />
      <SkillsSection />
      <ProjectsSection />
      <ExperienceTimeline />
      <ContactSection />
      <Footer />
    </div>
  );
};

export default HomePage;
